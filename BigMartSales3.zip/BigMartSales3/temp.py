# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt 



df_train = pd.read_csv('train_set.csv')
df_test = pd.read_csv('test_set.csv')
df_train.info()
print(df_train.head())


df_test.info()

print(df_train.dtypes)
df_train.info()

print(df_train.describe())
